package com.company;

public class Main {

    public static void main(String[] args) {
        Pug Pug1 = new Pug("Moisha",4,"pug bulldog");
        Setter Setter1 = new Setter("Albert",7,"english setter");
        Shiba Shiba1 = new Shiba("Doromaru",3,"Shiba Ino");
        Pug1.displayInfo();
        Setter1.displayInfo();
        Shiba1.displayInfo();
    }
}
